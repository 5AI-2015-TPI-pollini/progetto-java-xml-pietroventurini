<h2>Geocode Project</h2>
<h3>Description ▼</h3>

This is a project assigned in November 2015 at IIS Castelli (5AI). It's a program that retrieve info about places and their respective weather from two web services.

<h3>Functioning ▼</h3>

Geocode Project works using APIs from Google Maps and OpenWeather for retrieving data in XML.

<h3>Wiki ▼</h3>

User's guide:
